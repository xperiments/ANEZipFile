			//
			//  ANEZipFile.m
			//  ANEZipFile
			//
			//  Created by ANEBridgeCreator on 10/02/2013.
			//  Copyright (c)2013 ANEBridgeCreator. All rights reserved.
			//
			
			#import "FlashRuntimeExtensions.h"
			
			#define DEFINE_ANE_FUNCTION(fn) FREObject (fn)(FREContext context, void* functionData, uint32_t argc, FREObject argv[])
			#define DISPATCH_STATUS_EVENT(extensionContext, code, status) FREDispatchStatusEventAsync((extensionContext), (uint8_t*)code, (uint8_t*)status)
			#define MAP_FUNCTION(fn, data) { (const uint8_t*)(#fn), (data), &(fn) }
			
			#define ASSERT_ARGC_IS(fn_name, required)																	\
			if(argc != (required))																						\
			{																											\
				DISPATCH_INTERNAL_ERROR(context, #fn_name ": Wrong number of arguments. Expected exactly " #required);	\
				return NULL;																							\
			}
			#define ASSERT_ARGC_AT_LEAST(fn_name, required)																\
			if(argc < (required))																						\
			{																											\
				DISPATCH_INTERNAL_ERROR(context, #fn_name ": Wrong number of arguments. Expected at least " #required);	\
				return NULL;																							\
			}
			
			/****************************************************************************************
			 *																						*
			 *	PROPERTIES GETTERS/SETTERS															*
			 *																						*
			 ****************************************************************************************/
			
			 
			
			
			
			/****************************************************************************************
			 *																						*
			 *	METHODS BRIDGED																		*
			 *																						*
			 ****************************************************************************************/
			
			/****************************************************************************************
			 * @method:close( ):Boolean
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( close )
			{
				
				//  return->as3 ( resultFromBoolean as Boolean );
				uint32_t resultFromBoolean= 0;
				FREObject ane_resultFromBoolean= nil;
				FRENewObjectFromBool(resultFromBoolean, &ane_resultFromBoolean);
				
				return ane_resultFromBoolean;
			
			}
			
			
			/****************************************************************************************
			 * @method:createZipFile( path:String,withFilesAtPaths:Array):Boolean
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( createZipFile )
			{
				
				//  path:String = argument[0];
			
				uint32_t pathLength;
				const uint8_t *path_CString;
				FREGetObjectAsUTF8(argv[0], &pathLength, &path_CString);
				NSString *path = [NSString stringWithUTF8String:(char*)path_CString];
				
			
				//  withFilesAtPaths:Array = argument[1];
			
				FREObject withFilesAtPaths = argv[1];
				uint32_t withFilesAtPathsLength;
				FREGetArrayLength(withFilesAtPaths, &withFilesAtPathsLength);
				for( int32_t i=0; i<withFilesAtPathsLength ;i++ )
				{
					// get an element at index
					FREObject withFilesAtPathsArrayElement;
					FREGetArrayElementAt(withFilesAtPaths, i, &withFilesAtPathsArrayElement);
					//
					// Process your array element here
					//
				}
				
			
				//  return->as3 ( resultFromBoolean as Boolean );
				uint32_t resultFromBoolean= 0;
				FREObject ane_resultFromBoolean= nil;
				FRENewObjectFromBool(resultFromBoolean, &ane_resultFromBoolean);
				
				return ane_resultFromBoolean;
			
			}
			
			
			/****************************************************************************************
			 * @method:initWithPath( path:String):void
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( initWithPath )
			{
				
				//  path:String = argument[0];
			
				uint32_t pathLength;
				const uint8_t *path_CString;
				FREGetObjectAsUTF8(argv[0], &pathLength, &path_CString);
				NSString *path = [NSString stringWithUTF8String:(char*)path_CString];
				
			
				return NULL;
			}
			
			
			/****************************************************************************************
			 * @method:open( ):Boolean
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( open )
			{
				
				//  return->as3 ( resultFromBoolean as Boolean );
				uint32_t resultFromBoolean= 0;
				FREObject ane_resultFromBoolean= nil;
				FRENewObjectFromBool(resultFromBoolean, &ane_resultFromBoolean);
				
				return ane_resultFromBoolean;
			
			}
			
			
			/****************************************************************************************
			 * @method:unzipFile( path:String,destination:String,overwrite:Boolean,password:String):Boolean
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( unzipFile )
			{
				
				//  path:String = argument[0];
			
				uint32_t pathLength;
				const uint8_t *path_CString;
				FREGetObjectAsUTF8(argv[0], &pathLength, &path_CString);
				NSString *path = [NSString stringWithUTF8String:(char*)path_CString];
				
			
				//  destination:String = argument[1];
			
				uint32_t destinationLength;
				const uint8_t *destination_CString;
				FREGetObjectAsUTF8(argv[1], &destinationLength, &destination_CString);
				NSString *destination = [NSString stringWithUTF8String:(char*)destination_CString];
				
			
				//  overwrite:Boolean = argument[2];
			
				uint32_t overwrite_C;
				if( FREGetObjectAsBool(argv[2], &overwrite_C) != FRE_OK ) return NULL;
				
			
				//  password:String = argument[3];
			
				uint32_t passwordLength;
				const uint8_t *password_CString;
				FREGetObjectAsUTF8(argv[3], &passwordLength, &password_CString);
				NSString *password = [NSString stringWithUTF8String:(char*)password_CString];
				
			
				//  return->as3 ( resultFromBoolean as Boolean );
				uint32_t resultFromBoolean= 0;
				FREObject ane_resultFromBoolean= nil;
				FRENewObjectFromBool(resultFromBoolean, &ane_resultFromBoolean);
				
				return ane_resultFromBoolean;
			
			}
			
			
			/****************************************************************************************
			 * @method:writeData( data:ByteArray,fileName:String):Boolean
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( writeData )
			{
				
				//  data:ByteArray = argument[0];
			
				//  Define variables for class instance ByteArray
					
				//  Fill FREObjects with class variables properties
				
				//  Fill all the new class instance properties
			
				//  fileName:String = argument[1];
			
				uint32_t fileNameLength;
				const uint8_t *fileName_CString;
				FREGetObjectAsUTF8(argv[1], &fileNameLength, &fileName_CString);
				NSString *fileName = [NSString stringWithUTF8String:(char*)fileName_CString];
				
			
				//  return->as3 ( resultFromBoolean as Boolean );
				uint32_t resultFromBoolean= 0;
				FREObject ane_resultFromBoolean= nil;
				FRENewObjectFromBool(resultFromBoolean, &ane_resultFromBoolean);
				
				return ane_resultFromBoolean;
			
			}
			
			
			/****************************************************************************************
			 * @method:writeFile( path:String):Boolean
			 ****************************************************************************************/
			DEFINE_ANE_FUNCTION( writeFile )
			{
				
				//  path:String = argument[0];
			
				uint32_t pathLength;
				const uint8_t *path_CString;
				FREGetObjectAsUTF8(argv[0], &pathLength, &path_CString);
				NSString *path = [NSString stringWithUTF8String:(char*)path_CString];
				
			
				//  return->as3 ( resultFromBoolean as Boolean );
				uint32_t resultFromBoolean= 0;
				FREObject ane_resultFromBoolean= nil;
				FRENewObjectFromBool(resultFromBoolean, &ane_resultFromBoolean);
				
				return ane_resultFromBoolean;
			
			}
			
			
			/****************************************************************************************
			 *																						*
			 *	EXTENSION & CONTEXT																	*
			 *																						*
			 ****************************************************************************************/
			
			void ANEZipFileContextInitializer( void* extData, const uint8_t* ctxType, FREContext ctx, uint32_t* numFunctionsToSet, const FRENamedFunction** functionsToSet )
			{
				static FRENamedFunction functionMap[] = {
					// METHODS
					MAP_FUNCTION( close, NULL ),
					MAP_FUNCTION( createZipFile, NULL ),
					MAP_FUNCTION( initWithPath, NULL ),
					MAP_FUNCTION( open, NULL ),
					MAP_FUNCTION( unzipFile, NULL ),
					MAP_FUNCTION( writeData, NULL ),
					MAP_FUNCTION( writeFile, NULL )
				};
				*numFunctionsToSet = sizeof( functionMap ) / sizeof( FRENamedFunction );
				*functionsToSet = functionMap;
			}
			void ANEZipFileContextFinalizer( FREContext ctx )
			{
				NSLog(@"Entering ANEZipFileContextFinalizer()");
				NSLog(@"Exiting ANEZipFileContextFinalizer()");
				return;
			}
			void ANEZipFileExtensionInitializer( void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet ) 
			{ 
				NSLog(@"Entering ANEZipFileExtensionInitializer()");
				extDataToSet = NULL;  // This example does not use any extension data.
				*ctxInitializerToSet = &ANEZipFileContextInitializer;
				*ctxFinalizerToSet = &ANEZipFileContextFinalizer;
			}
			void ANEZipFileExtensionFinalizer()
			{
				NSLog(@"Entering ANEZipFileExtensionFinalizer()");
				return;
			}
			